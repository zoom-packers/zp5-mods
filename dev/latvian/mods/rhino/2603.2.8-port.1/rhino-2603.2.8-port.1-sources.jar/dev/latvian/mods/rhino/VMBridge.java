/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// API class

package dev.latvian.mods.rhino;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class VMBridge {
	public static boolean tryToMakeAccessible(Object target, AccessibleObject accessible) {
		if (accessible.canAccess(target)) {
			return true;
		}

		try {
			accessible.setAccessible(true);
		} catch (Exception ex) {
		}

		return accessible.canAccess(target);
	}

	public static Object getInterfaceProxyHelper(Context cx, Class<?>[] interfaces) {
		// XXX: How to handle interfaces array withclasses from different
		// class loaders? Using cf.getApplicationClassLoader() ?
		ClassLoader loader = interfaces[0].getClassLoader();
		Class<?> cl = Proxy.getProxyClass(loader, interfaces);
		Constructor<?> c;
		try {
			c = cl.getConstructor(InvocationHandler.class);
		} catch (NoSuchMethodException ex) {
			// Should not happen
			throw new IllegalStateException(ex);
		}
		return c;
	}

	public record AdapterInvocationHandler(Context cx, InterfaceAdapter adapter, Object target, Scriptable topScope) implements InvocationHandler {
		@Override
		public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
			// In addition to methods declared in the interface, proxies
			// also route some java.lang.Object methods through the
			// invocation handler.
			if (method.getDeclaringClass() == Object.class) {
				String methodName = method.getName();
				switch (methodName) {
					case "equals" -> {
						// Note: we could compare a proxy and its wrapped function
						// as equal here but that would break symmetry of equal().
						// The reason == suffices here is that proxies are cached
						// in ScriptableObject (see NativeJavaObject.coerceType())
						return proxy == args[0];
					}
					case "hashCode" -> {
						return target.hashCode();
					}
					case "toString" -> {
						return "Proxy[" + target + "]";
					}
				}
			}

			if (method.isDefault() && !hasJSImplementation(method)) {
				return InvocationHandler.invokeDefault(proxy, method, args);
			} else {
				return adapter.invoke(cx, target, topScope, proxy, method, args);
			}
		}

		/**
		 * A JS object may override a default method by providing a function
		 * property of the same name; only fall back to the Java default
		 * implementation when it doesn't.
		 */
		private boolean hasJSImplementation(Method method) {
			if (target instanceof Callable) {
				return false;
			}
			return target instanceof Scriptable s && ScriptableObject.getProperty(s, method.getName(), cx) instanceof Callable;
		}
	}

	public static Object newInterfaceProxy(Object proxyHelper, final InterfaceAdapter adapter, final Object target, final Scriptable topScope, Context cx) {
		Constructor<?> c = (Constructor<?>) proxyHelper;

		try {
			return c.newInstance(new AdapterInvocationHandler(cx, adapter, target, topScope));
		} catch (InvocationTargetException ex) {
			throw Context.throwAsScriptRuntimeEx(ex, cx);
		} catch (IllegalAccessException | InstantiationException ex) {
			// Should not happen
			throw new IllegalStateException(ex);
		}
	}
}
