/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package dev.latvian.mods.rhino;

import com.google.common.collect.ImmutableMap;
import dev.latvian.mods.rhino.type.ParameterizedTypeInfo;
import dev.latvian.mods.rhino.type.TypeInfo;
import dev.latvian.mods.rhino.type.VariableTypeInfo;
import dev.latvian.mods.rhino.util.DefaultValueTypeHint;
import dev.latvian.mods.rhino.util.Deletable;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/**
 * This class reflects non-Array Java objects into the JavaScript environment.  It
 * reflect fields directly, and uses NativeJavaMethod objects to reflect (possibly
 * overloaded) methods.<p>
 *
 * @author Mike Shaver
 * @see NativeJavaArray
 * @see NativeJavaClass
 */

public class NativeJavaObject implements Scriptable, SymbolScriptable, Wrapper {
	static void init(ScriptableObject scope, boolean sealed, Context cx) {
		JavaIterableIterator.init(scope, sealed, cx);
	}

	/**
	 * The prototype of this object.
	 */
	protected Scriptable prototype;
	/**
	 * The parent scope of this object.
	 */
	protected Scriptable parent;
	protected transient Object javaObject;
	protected transient TypeInfo typeInfo;
	private transient Map<VariableTypeInfo, TypeInfo> typeMapping;
	protected transient JavaMembers members;
	protected transient Map<String, FieldAndMethods> fieldAndMethods;
	protected transient Map<String, CustomMember> customMembers;
	protected transient boolean isAdapter;

	public NativeJavaObject(Scriptable scope, Object javaObject, TypeInfo typeInfo, Context cx) {
		this(scope, javaObject, typeInfo, false, cx);
	}

	public NativeJavaObject(Scriptable scope, Object javaObject, TypeInfo typeInfo, boolean isAdapter, Context cx) {
		this.parent = scope;
		this.javaObject = javaObject;
		this.typeInfo = typeInfo;
		this.isAdapter = isAdapter;
		initMembers(cx, scope);
	}

	protected void initMembers(Context cx, Scriptable scope) {
		Class<?> dynamicType;
		if (javaObject != null) {
			dynamicType = javaObject.getClass();
		} else {
			dynamicType = typeInfo.asClass();
		}
		members = JavaMembers.lookupClass(cx, scope, dynamicType, typeInfo.asClass(), isAdapter);
		fieldAndMethods = members.getFieldAndMethodsObjects(this, javaObject, false, cx);
		customMembers = null;
	}

	/**
	 * get mapping for argTypes that are already 'flattened' the type variable used by the current
	 * class, so here we only need to convert type variables of current class to the actual type.
	 * <p>
	 * for example, an object is previously obtained via "public A<String> getA();" method, where
	 * the A is "class A<T1> { ... }". Then we only need to use mapping 'T1 -> String' to convert
	 * argTypes once
	 * <p>
	 * where are the arg types 'flattened': {@link CachedExecutableInfo#getParameters()}
	 */
	public Map<VariableTypeInfo, TypeInfo> getTypeMapping() {
		if (typeMapping == null) {
			if (typeInfo instanceof ParameterizedTypeInfo parameterized) {
				var parameters = parameterized.asClass().getTypeParameters();
				if (parameters.length == 1) {
					typeMapping = Collections.singletonMap(TypeInfo.of(parameters[0]), parameterized.param(0));
				} else {
					var mapping = ImmutableMap.<VariableTypeInfo, TypeInfo>builder();
					for (int i = 0, size = parameters.length; i < size; i++) {
						mapping.put(TypeInfo.of(parameters[i]), parameterized.param(i));
					}
					typeMapping = mapping.build();
				}
			} else {
				typeMapping = Collections.emptyMap();
			}
		}
		return typeMapping;
	}

	public void addCustomMember(CustomMember member) {
		if (customMembers == null) {
			customMembers = new HashMap<>();
		}

		customMembers.put(member.name(), member);
	}

	protected void addCustomFunction(String name, TypeInfo returnType, CustomFunction.Func func, TypeInfo... argTypes) {
		addCustomMember(new CustomMember(name, returnType, new CustomFunction(name, func, argTypes)));
	}

	protected void addCustomFunction(String name, TypeInfo returnType, CustomFunction.NoArgFunc func) {
		addCustomFunction(name, returnType, func, TypeInfo.EMPTY_ARRAY);
	}

	public void addCustomProperty(String name, TypeInfo type, CustomProperty getter) {
		addCustomMember(new CustomMember(name, type, getter));
	}

	@Override
	public boolean has(Context cx, String name, Scriptable start) {
		return members.has(cx, name, false) || customMembers != null && customMembers.containsKey(name);
	}

	@Override
	public boolean has(Context cx, int index, Scriptable start) {
		return false;
	}

	@Override
	public boolean has(Context cx, Symbol key, Scriptable start) {
		return javaObject instanceof Iterable<?> && SymbolKey.ITERATOR.equals(key);
	}

	@Override
	public Object get(Context cx, String name, Scriptable start) {
		if (fieldAndMethods != null) {
			Object result = fieldAndMethods.get(name);
			if (result != null) {
				return result;
			}
		}

		if (customMembers != null) {
			var member = customMembers.get(name);

			if (member != null) {
				var value = member.value();

				if (value instanceof CustomProperty p) {
					value = p.get(cx);
				}

				return cx.javaToJS(value, start, member.type());
			}
		}

		// TODO: passing 'this' as the scope is bogus since it has no parent scope
		return members.get(this, name, javaObject, false, cx);
	}

	@Override
	public Object get(Context cx, Symbol key, Scriptable start) {
		if (javaObject instanceof Iterable<?> && SymbolKey.ITERATOR.equals(key)) {
			return symbol_iterator;
		}

		// Native Java objects have no Symbol members
		return Scriptable.NOT_FOUND;
	}

	@Override
	public Object get(Context cx, int index, Scriptable start) {
		throw members.reportMemberNotFound(Integer.toString(index), cx);
	}

	@Override
	public void put(Context cx, String name, Scriptable start, Object value) {
		// We could be asked to modify the value of a property in the
		// prototype. Since we can't add a property to a Java object,
		// we modify it in the prototype rather than copy it down.
		if (prototype == null || members.has(cx, name, false)) {
			members.put(this, name, javaObject, value, false, cx);
		} else {
			prototype.put(cx, name, prototype, value);
		}
	}

	@Override
	public void put(Context cx, Symbol symbol, Scriptable start, Object value) {
		// We could be asked to modify the value of a property in the
		// prototype. Since we can't add a property to a Java object,
		// we modify it in the prototype rather than copy it down.
		String name = symbol.toString();
		if (prototype == null || members.has(cx, name, false)) {
			members.put(this, name, javaObject, value, false, cx);
		} else if (prototype instanceof SymbolScriptable) {
			((SymbolScriptable) prototype).put(cx, symbol, prototype, value);
		}
	}

	@Override
	public void put(Context cx, int index, Scriptable start, Object value) {
		throw members.reportMemberNotFound(Integer.toString(index), cx);
	}

	@Override
	public boolean hasInstance(Context cx, Scriptable value) {
		// This is an instance of a Java class, so always return false
		return false;
	}

	@Override
	public void delete(Context cx, String name) {
		if (fieldAndMethods != null) {
			Object result = fieldAndMethods.get(name);
			if (result != null) {
				Deletable.deleteObject(result);
				return;
			}
		}

		if (customMembers != null) {
			Object result = customMembers.get(name);
			if (result != null) {
				Deletable.deleteObject(result);
				return;
			}
		}

		Deletable.deleteObject(members.get(this, name, javaObject, false, cx));
	}

	@Override
	public void delete(Context cx, Symbol key) {
	}

	@Override
	public void delete(Context cx, int index) {
	}

	@Override
	public Scriptable getPrototype(Context cx) {
		if (prototype == null && javaObject instanceof String) {
			return TopLevel.getBuiltinPrototype(ScriptableObject.getTopLevelScope(parent), TopLevel.Builtins.String, cx);
		}
		return prototype;
	}

	/**
	 * Sets the prototype of the object.
	 */
	@Override
	public void setPrototype(Scriptable m) {
		prototype = m;
	}

	/**
	 * Returns the parent (enclosing) scope of the object.
	 */
	@Override
	public Scriptable getParentScope() {
		return parent;
	}

	/**
	 * Sets the parent (enclosing) scope of the object.
	 */
	@Override
	public void setParentScope(Scriptable m) {
		parent = m;
	}

	@Override
	public Object[] getIds(Context cx) {
		if (customMembers != null) {
			Object[] c = customMembers.keySet().toArray(ScriptRuntime.EMPTY_OBJECTS);
			Object[] m = members.getIds(false);
			Object[] result = new Object[c.length + m.length];
			System.arraycopy(c, 0, result, 0, c.length);
			System.arraycopy(m, 0, result, c.length, m.length);
			return result;
		}

		return members.getIds(false);
	}

	@Override
	public Object unwrap() {
		return javaObject;
	}

	@Override
	public String getClassName() {
		return "JavaObject";
	}

	@Override
	public Object getDefaultValue(Context cx, DefaultValueTypeHint hint) {
		Object value;
		if (hint == null) {
			if (javaObject instanceof Boolean) {
				hint = DefaultValueTypeHint.BOOLEAN;
			}
			if (javaObject instanceof Number) {
				hint = DefaultValueTypeHint.NUMBER;
			}
		}
		if (hint == null || hint == DefaultValueTypeHint.STRING) {
			value = javaObject.toString();
		} else {
			String converterName;
			if (hint == DefaultValueTypeHint.BOOLEAN) {
				converterName = "booleanValue";
			} else if (hint == DefaultValueTypeHint.NUMBER) {
				converterName = "doubleValue";
			} else {
				throw Context.reportRuntimeError0("msg.default.value", cx);
			}
			Object converterObject = get(cx, converterName, this);
			if (converterObject instanceof Function f) {
				value = f.call(cx, f.getParentScope(), this, ScriptRuntime.EMPTY_OBJECTS);
			} else {
				if (hint == DefaultValueTypeHint.NUMBER && javaObject instanceof Boolean) {
					boolean b = (Boolean) javaObject;
					value = b ? ScriptRuntime.wrapNumber(1.0) : ScriptRuntime.zeroObj;
				} else {
					value = javaObject.toString();
				}
			}
		}
		return value;
	}

	@Override
	public boolean equals(Object obj) {
		return obj != null && obj.getClass().equals(getClass()) && Objects.equals(((NativeJavaObject) obj).javaObject, javaObject);
	}

	@Override
	public int hashCode() {
		return javaObject == null ? 0 : javaObject.hashCode();
	}

	private static final Callable symbol_iterator = (Context cx, Scriptable scope, Scriptable thisObj, Object[] args) -> {
		if (!(thisObj instanceof NativeJavaObject)) {
			throw ScriptRuntime.typeError1(cx, "msg.incompat.call", SymbolKey.ITERATOR);
		}
		Object javaObject = ((NativeJavaObject) thisObj).javaObject;
		if (!(javaObject instanceof Iterable)) {
			throw ScriptRuntime.typeError1(cx, "msg.incompat.call", SymbolKey.ITERATOR);
		}
		return new JavaIterableIterator(cx, scope, (Iterable<?>) javaObject);
	};

	private static final class JavaIterableIterator extends ES6Iterator {
		private static final String ITERATOR_TAG = "JavaIterableIterator";

		static void init(ScriptableObject scope, boolean sealed, Context cx) {
			init(scope, sealed, new JavaIterableIterator(), ITERATOR_TAG, cx);
		}

		/**
		 * Only for constructing the prototype object.
		 */
		private JavaIterableIterator() {
			super();
			this.iterator = Collections.emptyIterator();
		}

		JavaIterableIterator(Context cx, Scriptable scope, Iterable<?> iterable) {
			super(scope, ITERATOR_TAG, cx);
			this.iterator = iterable.iterator();
		}

		@Override
		public String getClassName() {
			return "Java Iterable Iterator";
		}

		@Override
		protected boolean isDone(Context cx, Scriptable scope) {
			return !iterator.hasNext();
		}

		@Override
		protected Object nextValue(Context cx, Scriptable scope) {
			if (!iterator.hasNext()) {
				return Undefined.INSTANCE;
			}
			return cx.javaToJS(iterator.next(), scope);
		}

		@Override
		protected String getTag() {
			return ITERATOR_TAG;
		}

		private final Iterator<?> iterator;
	}
}
