/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package dev.latvian.mods.rhino.regexp;

import dev.latvian.mods.rhino.Callable;
import dev.latvian.mods.rhino.Context;
import dev.latvian.mods.rhino.ES6Iterator;
import dev.latvian.mods.rhino.ScriptRuntime;
import dev.latvian.mods.rhino.Scriptable;
import dev.latvian.mods.rhino.ScriptableObject;
import dev.latvian.mods.rhino.Undefined;

// See ECMAScript spec 22.2.9.1
public final class NativeRegExpStringIterator extends ES6Iterator {
	private static final long serialVersionUID = 1L;
	private static final String ITERATOR_TAG = "RegExpStringIterator";

	private Scriptable regexp;
	private String string;
	private boolean global;
	private boolean fullUnicode;
	private boolean nextDone;
	private Object next = null;

	public static void init(ScriptableObject scope, boolean sealed, Context cx) {
		ES6Iterator.init(scope, sealed, new NativeRegExpStringIterator(), ITERATOR_TAG, cx);
	}

	/** Only for constructing the prototype object. */
	private NativeRegExpStringIterator() {
		super();
	}

	public NativeRegExpStringIterator(Context cx, Scriptable scope, Scriptable regexp, String string, boolean global, boolean fullUnicode) {
		super(scope, ITERATOR_TAG, cx);

		this.regexp = regexp;
		this.string = string;
		this.global = global;
		this.fullUnicode = fullUnicode;
		this.nextDone = false;
	}

	@Override
	public String getClassName() {
		return "RegExp String Iterator";
	}

	@Override
	protected boolean isDone(Context cx, Scriptable scope) {
		// The base class calls _first_ isDone and _then_ nextValue, so we'll just compute the next
		// value here and return it from "nextValue".
		// Also, for non-global regexp, we need to return the first match and then "done" on the
		// next iteration.

		if (nextDone) {
			return true;
		}

		next = regExpExec(cx, scope);
		if (next == null) {
			// Done! Point ii of the spec
			next = Undefined.INSTANCE;
			nextDone = true;
			return true;
		} else if (!global) {
			// Return false at this iteration, but true at the next. Point iii of the spec
			nextDone = true;
			return false;
		}

		// Increment index if matched empty string, as per the spec, point v.
		String matchStr = ScriptRuntime.toString(cx, ScriptRuntime.getObjectIndex(cx, scope, next, 0));
		if (matchStr.isEmpty()) {
			long thisIndex = ScriptRuntime.toLength(cx, ScriptRuntime.getObjectProp(cx, scope, regexp, "lastIndex"));
			long nextIndex = ScriptRuntime.advanceStringIndex(string, thisIndex, fullUnicode);
			ScriptRuntime.setObjectProp(cx, scope, regexp, "lastIndex", nextIndex);
		}

		return false;
	}

	@Override
	protected Object nextValue(Context cx, Scriptable scope) {
		return next;
	}

	private Object regExpExec(Context cx, Scriptable scope) {
		// See ECMAScript spec 22.2.7.1
		Object execMethod = ScriptRuntime.getObjectProp(cx, scope, regexp, "exec");
		if (execMethod instanceof Callable) {
			return ((Callable) execMethod).call(cx, scope, regexp, new Object[]{string});
		}
		return NativeRegExp.js_exec(cx, scope, regexp, new Object[]{string});
	}

	@Override
	protected String getTag() {
		return ITERATOR_TAG;
	}
}
