/* -*- Mode: java; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package dev.latvian.mods.rhino.ast;

import dev.latvian.mods.rhino.Token;

/**
 * Node representing a catch-clause of a try-statement.
 * Node type is {@link Token#CATCH}.
 *
 * <pre><i>CatchClause</i> :
 *        <b>catch</b> ( <i><b>Identifier</b></i> [<b>if</b> Expression] ) Block</pre>
 */
public class CatchClause extends AstNode {

	private AstNode varName;
	private AstNode catchCondition;
	private Block body;
	private int ifPosition = -1;
	private int lp = -1;
	private int rp = -1;

	{
		type = Token.CATCH;
	}

	public CatchClause() {
	}

	public CatchClause(int pos) {
		super(pos);
	}

	public CatchClause(int pos, int len) {
		super(pos, len);
	}

	/**
	 * Returns catch variable node
	 *
	 * @return catch variable
	 */
	public AstNode getVarName() {
		return varName;
	}

	/**
	 * Sets catch variable node, and sets its parent to this node.
	 *
	 * @param varName catch variable. Can be {@code null} for an optional catch binding
	 *                ("catch { ... }" with no variable bound at all).
	 */
	public void setVarName(AstNode varName) {
		this.varName = varName;
		if (varName != null) {
			varName.setParent(this);
		}
	}

	/**
	 * Returns catch condition node, if present
	 *
	 * @return catch condition node, {@code null} if not present
	 */
	public AstNode getCatchCondition() {
		return catchCondition;
	}

	/**
	 * Sets catch condition node, and sets its parent to this node.
	 *
	 * @param catchCondition catch condition node.  Can be {@code null}.
	 */
	public void setCatchCondition(AstNode catchCondition) {
		this.catchCondition = catchCondition;
		if (catchCondition != null) {
			catchCondition.setParent(this);
		}
	}

	/**
	 * Returns catch body
	 */
	public Block getBody() {
		return body;
	}

	/**
	 * Sets catch body, and sets its parent to this node.
	 *
	 * @throws IllegalArgumentException if body is {@code null}
	 */
	public void setBody(Block body) {
		assertNotNull(body);
		this.body = body;
		body.setParent(this);
	}

	/**
	 * Returns left paren position
	 */
	public int getLp() {
		return lp;
	}

	/**
	 * Sets left paren position
	 */
	public void setLp(int lp) {
		this.lp = lp;
	}

	/**
	 * Returns right paren position
	 */
	public int getRp() {
		return rp;
	}

	/**
	 * Sets right paren position
	 */
	public void setRp(int rp) {
		this.rp = rp;
	}

	/**
	 * Sets both paren positions
	 */
	public void setParens(int lp, int rp) {
		this.lp = lp;
		this.rp = rp;
	}

	/**
	 * Returns position of "if" keyword
	 *
	 * @return position of "if" keyword, if present, or -1
	 */
	public int getIfPosition() {
		return ifPosition;
	}

	/**
	 * Sets position of "if" keyword
	 *
	 * @param ifPosition position of "if" keyword, if present, or -1
	 */
	public void setIfPosition(int ifPosition) {
		this.ifPosition = ifPosition;
	}
}
