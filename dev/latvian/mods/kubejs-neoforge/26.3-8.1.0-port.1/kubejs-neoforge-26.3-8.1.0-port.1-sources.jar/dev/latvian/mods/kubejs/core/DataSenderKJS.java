package dev.latvian.mods.kubejs.core;

import dev.latvian.mods.rhino.util.RemapPrefixForJS;
import net.minecraft.nbt.CompoundTag;
import org.jspecify.annotations.Nullable;

@RemapPrefixForJS("kjs$")
public interface DataSenderKJS {
	default void kjs$sendData(String channel, @Nullable CompoundTag data) {
		throw new NoMixinException();
	}

	default void kjs$sendData(String channel) {
		kjs$sendData(channel, null);
	}
}