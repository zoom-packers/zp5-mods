package dev.latvian.mods.kubejs.block.custom;

import dev.latvian.mods.kubejs.generator.KubeAssetGenerator;
import dev.latvian.mods.rhino.util.ReturnsSelf;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CarpetBlock;

@ReturnsSelf
public class CarpetBlockBuilder extends ShapedBlockBuilder {
	public static final Identifier[] CARPET_TAGS = {
		BlockTags.WOOL_CARPETS.location(),
	};

	private static final Identifier MODEL = Identifier.withDefaultNamespace("block/carpet");

	public CarpetBlockBuilder(Identifier i) {
		super(i, "_carpet");
		tagBoth(CARPET_TAGS);
	}

	@Override
	public Block createObject() {
		return new CarpetBlock(createProperties());
	}

	@Override
	protected void generateBlockModels(KubeAssetGenerator generator) {
		generator.blockModel(id, m -> {
			m.parent(MODEL);
			m.texture("wool", baseTexture);
		});
	}
}
