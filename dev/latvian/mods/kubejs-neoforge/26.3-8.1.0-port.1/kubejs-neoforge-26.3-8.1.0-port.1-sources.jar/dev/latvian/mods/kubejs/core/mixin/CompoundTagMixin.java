package dev.latvian.mods.kubejs.core.mixin;

import dev.latvian.mods.kubejs.core.NativeCompoundTag;
import dev.latvian.mods.rhino.Context;
import dev.latvian.mods.rhino.Scriptable;
import dev.latvian.mods.rhino.type.TypeInfo;
import dev.latvian.mods.rhino.util.CustomJavaToJsWrapper;
import dev.latvian.mods.rhino.util.HideFromJS;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.Map;

@Mixin(CompoundTag.class)
public abstract class CompoundTagMixin implements CustomJavaToJsWrapper {
	@Unique
	private static final TypeInfo KJS$MAP_TYPE = TypeInfo.RAW_MAP.withParams(TypeInfo.STRING, TypeInfo.of(Tag.class));

	@Shadow
	@Final
	public Map<String, Tag> tags;

	@Override
	public Scriptable convertJavaToJs(Context cx, Scriptable scope, TypeInfo target) {
		return new NativeCompoundTag(cx, scope, this, tags, KJS$MAP_TYPE);
	}

	@Shadow
	@HideFromJS
	public abstract void putByteArray(String key, byte[] value);

	@Shadow
	@HideFromJS
	public abstract void putIntArray(String key, int[] value);

	@Shadow
	@HideFromJS
	public abstract void putLongArray(String key, long[] value);
}
