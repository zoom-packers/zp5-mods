package dev.latvian.mods.kubejs.gui.chest;

import dev.latvian.mods.kubejs.core.InventoryKJS;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChestMenuSlot {
	public final ChestMenuData gui;
	public final int index;
	public final int x;
	public final int y;
	private ItemStack item;
	public int clicked;
	public Map<String, Object> data;
	public final List<ChestMenuClickHandler> clickHandlers;
	public @Nullable InventoryKJS inventory;
	public int inventorySlot;

	public ChestMenuSlot(ChestMenuData gui, int index) {
		this.gui = gui;
		this.index = index;
		this.x = index % 9;
		this.y = index / 9;
		this.item = ItemStack.EMPTY;
		this.clicked = 0;
		this.data = new HashMap<>();
		this.clickHandlers = new ArrayList<>(1);
		this.inventory = null;
		this.inventorySlot = -1;
	}

	@Override
	public String toString() {
		return "Slot[" + x + "," + y + "]";
	}

	public void setItem(ItemStack stack) {
		if (inventory != null && inventorySlot >= 0) {
			inventory.kjs$setStackInSlot(inventorySlot, stack);
		} else {
			item = stack;
		}
	}

	public ItemStack getItem() {
		if (inventory != null && inventorySlot >= 0) {
			return inventory.kjs$getStackInSlot(inventorySlot);
		}

		return item;
	}

	public void resetClickHandlers() {
		clickHandlers.clear();
	}

	public void clicked(ContainerInput type, int button, ChestMenuClickEvent.Callback callback, boolean autoHandle) {
		clickHandlers.add(new ChestMenuClickHandler(type, button, callback, autoHandle));
	}

	public void setLeftClicked(ChestMenuClickEvent.Callback callback) {
		clicked(ContainerInput.PICKUP, 0, callback, true);
	}

	public void setRightClicked(ChestMenuClickEvent.Callback callback) {
		clicked(ContainerInput.PICKUP, 1, callback, true);
	}

	public void setMiddleClicked(ChestMenuClickEvent.Callback callback) {
		clicked(ContainerInput.CLONE, 2, callback, true);
	}

	public void setSwapped(ChestMenuClickEvent.Callback callback) {
		clicked(ContainerInput.SWAP, -1, callback, true);
	}

	public void setThrown(ChestMenuClickEvent.Callback callback) {
		clicked(ContainerInput.THROW, -1, callback, true);
	}

	public void setShiftLeftClicked(ChestMenuClickEvent.Callback callback) {
		clicked(ContainerInput.QUICK_MOVE, 0, callback, true);
	}

	public void setShiftRightClicked(ChestMenuClickEvent.Callback callback) {
		clicked(ContainerInput.QUICK_MOVE, 1, callback, true);
	}

	public void setDoubleClicked(ChestMenuClickEvent.Callback callback) {
		clicked(ContainerInput.PICKUP_ALL, -1, callback, true);
	}
}